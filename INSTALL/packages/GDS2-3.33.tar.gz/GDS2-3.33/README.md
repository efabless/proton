GDS2
====

This is GDS2, a module for creating programs to read,
write, and manipulate GDS2 (GDSII) stream files.

GDS2 should be able to handle any size gdsii file but
I would consider it too slow for anything larger
than a few megabytes in size. If your files are are
closer to the gigabyte range please check out my
gdt programs at: http://sourceforge.net/projects/gds2/
which you can use to open and process GDS2 files
as a pipe from Perl.

2014: after 15 years I'm opening up this module for anyone
to take over in PAUSE (https://pause.perl.org/pause/).
Peace,
Ken Schumack

perl -le '$_=q(Zpbhgnpe@pvnt.uxa);$_=~tr/n-sa-gt-zh-mZ/a-zS/;print;'

